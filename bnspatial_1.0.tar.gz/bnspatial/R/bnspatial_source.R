### R wrapper to implement Bayesian Networks on raster data 
### Author: Dario Masante - dmasan@ceh.ac.uk (dario.masante@gmail.com)
### April 2016

## A crop yield model scenario simulation at the landscape scale, using continuous data, 
## where fertilisers application and irrigated are known spatial inputs. 
## Temperature is provided as, while Rainfall is an unknown variable

#' installMissingPackages
#'
#' This function loads required packages and installs missing ones, if any.
#' @param \code{multicores}	logical. Should use parallel processing? If TRUE will run using parallel functions from the "foreach" package
#' @keywords
#' @return
#' @author
#' @seealso
#' @references
#' @examples
#' function()
#' @export
installMissingPackages <- function(parallel=TRUE){
	if(parallel == TRUE){
		pack <- library(foreach, logical.return = TRUE)
		if(pack == FALSE){
			install.packages("foreach", repos="http://cran.uk.r-project.org/", dependencies=T, clean=T)
			install.packages("doParallel", repos="http://cran.uk.r-project.org/", dependencies=T, clean=T)
		}
		library(doParallel)
	}
	pack <- library(gRain, logical.return = TRUE)
	if(pack == FALSE){
		source("http://bioconductor.org/biocLite.R")
		biocLite("RBGL")
		install.packages("gRain", repos="http://cran.uk.r-project.org/", dependencies=T, clean=T)
		library(gRain)
	}
	pack <- library(raster, logical.return = TRUE)
	if(pack == FALSE){
		install.packages("raster", repos="http://cran.uk.r-project.org/", dependencies=T, clean=T)
		library(raster)
	}
}


#' loadNetwork
#' @title Load Bayesian network
#'
#' @description This function loads the Bayesian network from a native gRain object of class "grain" or an external file with extension .net (as provided from Hugin or GeNIe) and compiles the network given a target node of interest.
#' FIX UNDERSCORES REMOVAL (gRain:::.getNodeSpec AND gRain:::.toCamel)
#' @param \code{network}	The Bayesian network. Must be provided as character (the path to a ".net" file to be imported), or as object of class "grain".  
#' @param \code{target}	character. The node of interest to be modelled and mapped. Default set to NULL, otherwise the network will be compiled based on it for faster querying.
#' @keywords
#' @return	An object of class "grain". The Bayesian network. If \code{target} argument is provided the network is compiled for a faster querying .
#' @author
#' @details Bayesian networks from the package "bnlearn" can be imported via the function \code{as.grain}. 
#' ".net" file format as provided from Netica currently does not correspond to a valid Hugin .net file. 
#' @seealso \url{http://127.0.0.1:30968/library/gRain/html/loadHuginNet.html}
#' \url{http://127.0.0.1:30968/library/bnlearn/html/gRain%20integration.html}.
#' @references
#' @examples
#' data(bnspatial)
#' loadNetwork('LandUseChange.net', 'FinalLULC')
#' @export
loadNetwork <- function(network, target=NULL){
	if(class(network) == 'character' & length(network) == 1){
		net <- .loadHuginNet(network) #Load Bayesian network
	} else if (class(network) != "grain"){
		stop('Input "network" must be a .net file (from any external software such as Hugin, Netica or GeNIe), 
			or an object of class "grain" from the gRain package')
	}
	if(!is.null(target)){
		net <- compile(net, root=target, propagate=TRUE) #Compile network to speed up queries
	}
	return(net)
}

###
.loadHuginNet = function(file, description = rev(unlist(strsplit(file, "/")))[1], details = 0) {
    xxx <- gRain:::.readHuginNet(file, details)

    xxx$nodeList <- lapply(xxx$nodeList, .fixLines) ## This line fixes Genie quirk when saving .net files

    yyy <- gRain:::.transformHuginNet2internal(xxx)
    universe <- gRain:::.asUniverse(yyy)
    plist <- lapply(yyy$potentialList, gRain:::.hpot2cptable, universe)
    value <- gRain:::grain(gRain:::compileCPT(plist))
    return(value)
}

###
.fixLines <- function(nodeLines) {
	s <- which(grepl('states = ', nodeLines))
	while(grepl( ');', nodeLines[s]) == FALSE){
		nodeLines[s] <- paste(nodeLines[s], nodeLines[s+1], sep='')
		nodeLines <- nodeLines[-(s+1)]
	}
	return(nodeLines)
}


#' @name setClasses
#' @title Set classes/intervals (\code{setClasses, importClasses})
#' 
#' @description Functions \code{setClasses} and \code{importClasses} return a formatted list from given arguments, to be used for the Bayesian network and input spatial variables integration and error checking.
#' For \code{setClasses} a vector with node names and a list of vectors for both states of nodes and (optional) their boundaries in the spatial data 
#' must be provided, in the right order.
#' For \code{importClasses} a formatted text file must be provided (see below).
#' @aliases importClasses
#' @rdname setClasses
#' @param \code{classFile}	character. A text file where for each input variable associated to a node (see below) three lines are specified as follows: 
#' the first one indicates the node name, as in the Bayesian network; the second indicates the states associated with such variable, as they are in the Bayesian network;
#' the third one contains the values associated to each state in the spatial data (for discrete variables) or the class boundaries dividing the states (for continuous variables), including minimum and maximum
#' @param \code{nodes}	character. The nodes for which some information is known and available as spatial data
#' @param \code{states}	A list of characters. The states associated to each of the nodes (order must match \code{nodes} names)
#' @param \code{classBoundaries}	A list of numeric. The boundary values dividing nodes into corresponding states. For categorical variables the raster values associated to node states. Must be sorted in ascending order.
#' @keywords
#' @return A formatted list, specifying states break values for continuous nodes and integer values for categorical nodes.
#' @details As a reference for the formatting of the text file:
#' \strong{First line}: the node name.\cr
#' \strong{Second line}: the node states, comma separated (spaces allowed). \cr
#' \strong{Third line}: intervals from the spatial data associated to the states (integer values for discrete data and class boundaries, including endpoints, for continuous data). The same order as node states is required.\cr
#' 
#' For example:
#' 
#' \code{CurrentLULC} \cr
#' \code{forest,other,arable} \cr
#' \code{2, 1, 3} \cr
#' \code{Slope} \cr
#' \code{flat, moderate, steep} \cr
#' \code{-Inf, 1, 7, Inf} \cr
#' \code{LegalStatus} \cr
#' \code{public, private, protected} \cr
#' \code{4, 3, 1 }
#' @author
#' @seealso \code{\link{dataDiscretize}}
#' @references
#' @examples
#' importClasses('ConwyClasses.txt')
#' 
#' ### Same as:
#'
#' setClasses(c('Slope', 'CurrentLULC', 'LegalStatus'), 
#'	list(c('flat', 'moderate', 'steep'), c('forest', 'arable', 'other'), c('public', 'private', 'protected')),
#'	list(c(-Inf, 0, 5, Inf), c(2, 3, 1), (c(4, 3, 1)))
#' )
#' 
#' @export
setClasses <- function(nodes, states, classBoundaries){
	lst <- vector('list', length = length(nodes))
	names(lst) <- nodes
	for(i in 1:length(names(lst)) ){
		if(!identical(states[[i]], unique(states[[i]]))){
			print(states[[i]])
			stop('Non unique node state defined')
		}		
		lst[[i]]$States <- states[[i]]
		if(!identical(classBoundaries[[i]], unique(classBoundaries[[i]]))){
			print(classBoundaries[[i]])
			stop('Non unique "classBoundaries" defined')
		}
		if((length(classBoundaries[[i]]) - length(states[[i]])) %in% c(0, 1)){
			categorical <- ifelse(length(classBoundaries[[i]]) == length(states[[i]]), TRUE, FALSE)
		} else {
			stop('Number of classes does not match number of states. Also, for non categorical data 
				minimum and maximum boundaries must be set (-Inf and Inf allowed).')
		}
		lst[[i]]$ClassBoundaries <- classBoundaries[[i]]
		lst[[i]]$Categorical <- categorical
		if( identical(classBoundaries[[i]], sort(classBoundaries[[i]])) == FALSE & categorical == FALSE){
			print(classBoundaries[[i]])
			stop('"classBoundaries" for non categorical data must be sorted from lowest to highest')
		}
	}
	return(lst)
}

#' @rdname setClasses
#' @export
importClasses <- function(classFile){
	if(class(classFile) != 'character' | length(classFile) != 1){
		stop('Argument "classFile" must be a character vector of length one')
	}
	nodes <- vector()
	states <- list()
	classBoundaries <- list()
	classTxt <- scan(classFile, character(0), sep = "\n")
	for(i in seq(1, length(classTxt), by=3)){
		node <- classTxt[i]
		nodes <- c(nodes, node)
		state <- gsub(" ", "", unlist(strsplit(classTxt[i+1], ",")))
		states[[node]] <- state
		class <- as.numeric(gsub(" ", "", unlist(strsplit(classTxt[i+2], ","))))
		classBoundaries[[node]] <- class
	}
	setClasses(nodes=nodes, states=states, classBoundaries=classBoundaries)
}


#' linkNodeRaster
#' @title Link node to data
#'
#' @description This function links the available spatial data (in raster format) to the nodes of the Bayesian network. It returns a list of objects, including the spatial data and summary information about each node.
#' @param \code{layer}	character. The raster file of spatial data corresponding to a network node. 
#' @param \code{network}	an object of class "grain". The Bayesian network.
#' @param \code{node} character. A network node associated to the file in \code{layer} argument
#' @param \code{intervals} A list of numeric vectors. For categorical variables the raster values associated to each state of the node, for continuous variables the boundary values dividing into the corresponding states.
#' @param \code{categorical} logical. Is the node a categorical variable? Default is NULL.
#' @param \code{verbose}	logical. If \code{verbose = TRUE} a summary of class boundaries and associated nodes and data will be printed to screen for quick checks.
#' @keywords
#' @return	It returns a list of objects, including the spatial data and summary information about each node.
#' @details In future releases, this function may be rewritten to provide an S4 object instead of a list.
#' @author
#' @seealso \code{dataDiscretize}
#' @references
#' @examples
#' ## Load the Bayesian network
#' network <- loadNetwork('LandUseChange.net')
#' linkNodeRaster('ConwyLULC.tif', network, 'CurrentLULC', c(2, 3, 1))
#' @export
linkNodeRaster <- function(layer, network, node, intervals, categorical=NULL, verbose=TRUE){
	# Check correspondence of node and states names between lookup list and network
	checkName <- node %in% names(network$universe$levels)
	if(checkName == FALSE){
		print(node)
		stop('Node name provided does not match any node name from the network')		
	}
	states <- network$universe$levels[[node]]
	# Check correspondence of number of states and intervals
#	if(!is.null(intervals)) {
	if(!identical(intervals, unique(intervals))){
		stop('Non unique intervals defined')
	}
	delta <- length(intervals) - length(states)
	if(! delta %in% c(0, 1)){
		stop('Number of classes does not match number of states.')
	}
	if(!is.null(categorical)){
		if(categorical == TRUE & delta != 0) {
			stop('Number of classes does not match number of states.')
		} else if(categorical == FALSE & delta != 1) {
			stop('Number of intervals does not match number of states. For non categorical data 
				minimum and maximum boundaries must be set (-Inf and Inf allowed).')
		}
	}
	categorical <- ifelse(delta != 0, FALSE, TRUE)
	if( identical(intervals, sort(intervals)) == FALSE & categorical == FALSE){
		stop('"intervals" must be sorted from lowest to highest')
	}
	r <- raster::raster(layer)
	if(categorical == TRUE){
		v <- as.factor(getValues(r))
		if(is.null(intervals)){
			intervals <- as.numeric(levels(v))
			warning('For categorical data check classes integer value and corresponding states.
				If not matching as look up list should be provided (function "setClasses")
				or modified from current list.')
		} else {
			if(identical(as.numeric(levels(v)), sort(intervals)) == FALSE){
				stop('Integer values in categorical data do not match categories provided')
			}
		}
	} 
	
	lst <- list(list(States = states, Categorical = categorical, ClassBoundaries = intervals, FilePath = layer, Raster = r))
	names(lst) <- node
	if(verbose == TRUE){
		writeLines(c(paste('\n"', node, '"', ' points to:', sep=''), 
			paste(' -> ', layer, '\n'), 
			'With states:', 
			paste(states, collapse='    '), 
			ifelse(is.null(categorical), '', ifelse(categorical == TRUE, '\nRepresented by integer values:', '\nDiscretized by intervals:')), 
			paste(intervals, collapse= ' <-> '))
		)
		writeLines('----------------------------------')
	}
	return(lst)
}


#' linkNodeRasterList
#'
#' This function creates a list of lists, based on classes provided in the right format as from setClasses()
#' FIX ORDER OF NODES BETWEEN CLASSIFICATION AND SPATIALDATA
#' @param \code{spatialData}	character. The raster files corresponding to nodes 
#' @param \code{network}	an object of class "grain". The Bayesian network.
#' @param \code{classification} character or list. 
#' @param \code{categorical} logical. Is the node a categorical variable? Default is NULL.
#' @param \code{verbose}	logical. If TRUE a summary of class boundaries and associated nodes and data will be printed to screen for quick checks.
#' @keywords
#' @return
#' @author
#' @seealso
#' @references
#' @examples
#' ## Load the Bayesian network, the spatial data and the classification/discretisation lookup list
#' net <- loadNetwork('LandUseChange.net')
#' spatialData <- c('ConwyLULC.tif','ConwySlope.tif','LegalStatus.tif')
#' lookup <- importClasses('ConwyClasses.txt')
#' linkNodeRasterList(spatialData, net, lookup, verbose = FALSE)
#' @export
linkNodeRasterList <- function(spatialData, network, classification, verbose=TRUE){
	if(class(classification) == 'character' & length(classification) == 1){
		classification <- importClasses(classification)
	}
	if(length(spatialData) != length(classification)){
		stop('Spatial data files do not match the number of nodes provided in the look up list')
	}
	# Check correspondence of node and states names between lookup list and network
	# then iterate through the nodes and append to summary list
	lst <- list()
	for(nm in names(classification)){
		checkStates <- classification[[nm]]$States %in% network$universe$levels[[nm]]
		if(any(checkStates == FALSE)){
			stop(paste("Node states provided from the look up list do not match \n node states from the network: \n \n'", 
				classification[[nm]]$States[!checkStates], "' missing from network node", nm))
		}
		Categorical <- classification[[nm]]$Categorical
		if(Categorical == TRUE){
			sortedClasses <- match(network$universe$levels[[nm]],classification[[nm]]$States)
			ClassBoundaries <- classification[[nm]]$ClassBoundaries[sortedClasses]
		} else {
			ClassBoundaries <- classification[[nm]]$ClassBoundaries
		}
		lst[nm] <- linkNodeRaster(spatialData[ names(classification) == nm ], network=network, node=nm, 
			intervals=ClassBoundaries, categorical=Categorical, verbose=verbose)
	}
	return(lst)
}


#' @name AOI
#' @title Area Of Interest (AOI)
#'
#' @description This function creates a raster defining the area of interest, by unioning the input rasters or taking a user defined mask as reference.
#' Resolution and extent are set equal to those of the mask raster (\code{msk}) when specified, otherwise
#' to the finest resolution among input spatial data and as the union of extents of input data.
#' @param \code{spDataLst}	a formatted list of input rasters formatted character. The raster file corresponding to node 
#' @param \code{msk}	a character or an object of class "RasterLayer". The reference raster to be used as mask. 
#' All model outputs will have the same resolution and same extent as this raster. All locations with no data (i.e. NA) cells 
#' in this raster will be ignored as well.
#' @param \code{mskSubset}	vector. The values from \code{msk} which should be retained for building the area of interest
#' @keywords
#' @return
#' @author
#' @seealso
#' @references
#' @examples
#' ## Load network, spatial data and lookup list
#' net <- loadNetwork('LandUseChange.net')
#' spatialData <- c('ConwyLULC.tif', 'ConwySlope.tif', 'LegalStatus.tif')
#' lookup <- importClasses('ConwyClasses.txt')
#' spDataLst <- linkNodeRasterList(spatialData, net, lookup, verbose = FALSE)
#' AOI(spDataLst)
#' ##
#' plot(AOI(msk='ConwyLULC.tif'))
#' ##
#' mask <- raster('ConwyLULC.tif')
#' plot(AOI(msk=mask, mskSubset=c(2,3)))
#' @export
AOI <- function(spDataLst=NULL, msk=NULL, mskSubset=NULL){
	extent <- raster::extent
	res <- raster::res
	raster <- raster::raster
	if(is.null(msk)){
		if(is.null(spDataLst)) {
			stop('Must provide the area of interest or at least one data layer')
		}
		r <- spDataLst[[1]]$Raster
		ext <- extent(r)
		cellSizeX <- res(r)[1]
		cellSizeY <- res(r)[2]
		for(i in 1:length(spDataLst)){
			r <- spDataLst[[i]]$Raster
			ext <- raster::union(ext, extent(r) )
			cellSizeX <- ifelse(cellSizeX > res(r)[1], res(r)[1], cellSizeX)
			cellSizeY <- ifelse(cellSizeY > res(r)[2], res(r)[2], cellSizeY)
		}
		msk <- raster(xmn=ext[1], xmx=ext[2], ymn=ext[3], ymx=ext[4], ext=ext, resolution=c(cellSizeX, cellSizeY), vals = 1)
	} else {
		if(class(msk) != 'RasterLayer'){
			msk <- raster(msk)
		}
		id <- msk
		id[] <- 1:length(id)
		mskVals = getValues(msk)
		if(!is.null(mskSubset)){
			id <- getValues(id)[!is.na(mskVals) & mskVals %in% mskSubset]
		} else {
			id <- getValues(id)[!is.na(mskVals)]
		}
		msk[]<- NA
		msk[id] <- 1
	}
	return(msk)
}


#' extractValuesByMask
#' @title Extract raster values by mask
#' DEBUG!! NA missed
#' @description This function extracts the values from a given input raster based on a mask, by harmonizing resolution and extent with it.
#' @param \code{rast} an object of class "RasterLayer". The raster from which data will be extracted
#' @param \code{msk} an object of class "RasterLayer" or a two column matrix of coordinates. The reference raster (or coordinates) to be used as mask for extraction.
#' @keywords
#' @return
#' @author
#' @seealso
#' @references
#' @examples
#' mask <- AOI(msk='ConwyLULC.tif', mskSubset=c(2,3))
#' r <- raster('ConwySlope.tif')
#' head( extractValuesByMask(r, msk=mask)) 
#' @export
extractValuesByMask <- function(rast, msk){
	getValues <- raster::getValues
	if(class(rast) != 'RasterLayer'){
		stop('"rast" argument must be an object of "RasterLayer" class.')
	}
	if(class(msk) == 'RasterLayer'){
		id = msk
		id[] = 1:length(id)
		id = getValues(id)[!is.na(getValues(msk))]
		xy = xyFromCell(msk, id)
		cells = cellFromXY(rast, xy[, 1:2])
	} else if (class(msk) == 'matrix'){
		cells = cellFromXY(rast, msk[, 1:2])
	} else {
		stop('"msk" argument must be either an object of RasterLayer class or \n a matrix of coordinates "x" and "y"')
	}
	return( getValues(rast)[cells] )
}

#' dataDiscretize
#' @title Discretize data
#'
#' @description This function discretizes continuous input data into classes. Classes can be defined by the user or, if the user provides the number of expected classes, calculated from quantiles (default option) or by equal intervals. 
#' @param \code{data} numeric vector. The continuous data to be discretized.
#' @param \code{classBoundaries} numeric vector. Interval boundaries to be used for data discretization. Minimum and maximum are required ( \code{-Inf} or \code{Inf} are allowed, but to calculate the class mid values the minimum and maximum will be taken from the data), or a single integer to indicate the number of classes to split by quantiles or equal intervals.
#' @param \code{classStates}	vector. The state labels to be assigned to the discretised data.
#' @param \code{method}	character. What splitting method should be used? This argument does not apply if user defined values are passed to \code{classBoundaries}
#' \itemize{
#' \item{\code{quantile} (default option) splits data into quantiles. }
#' \item{\code{equal} splits data into equally sized interval based on minimum and maximum values in the data. }} \cr
#' @keywords
#' @return A named list of 4 vectors: 
#' \itemize{
#' \item{\code{$discreteData}	the discretized data, labels are applied accordingly if \code{classStates} argument is provided}
#' \item{\code{$classBoundaries}	the class boundaries, i.e. values defining the classes}
#' \item{\code{$midValues}	the mid point for each class (the mean of its lower and upper boundaries)}
#' \item{\code{$classStates}	the labels assigne to each class}
#' }
#' @details
#' @author
#' @seealso
#' @references
#' @examples
#' s = runif(100)
#'
#' #Split by user defined values. Values out of boundaries are set to NA:
#' dataDiscretize(s, classBoundaries=c(0.2, 0.5, 0.8)) 
#'
#' #Split by quantiles (default):
#' dataDiscretize(s, classStates=c('a', 'b', 'c'))
#'
#' #Split by equal intervals:
#' dataDiscretize(s, classStates=c('a', 'b', 'c'), method="equal")
#'
#' ## When -Inf and Inf are provided as external boundaries, $midValues of outer classes are calculated on the minimum and maximum values:
#' dataDiscretize(s, classBoundaries=c(0, 0.5, 1), classStates=c("first", "second"))
#' dataDiscretize(s, classBoundaries=c(-Inf, 0.5, Inf), classStates=c("first", "second"))
#' @export
dataDiscretize <- function(data, classBoundaries=NULL, classStates=NULL, method="quantile"){
	if(is.null(classBoundaries)){
		if(is.null(classStates)){ 
			stop('Must provide either "classBoundaries", "classStates" or both') 
		} else {
			classBoundaries <- length(classStates)
		}
	}
	if(length(classBoundaries) == 1){
		if(!is.null(classStates) & classBoundaries != length(classStates)){
			stop('Number of bins must match the number of states')
		}
		if(classBoundaries < 2 | abs(classBoundaries - round(classBoundaries)) > 0 ){
			stop('"classBoundaries" must be an integer greater than 1, \n 
				or a vector of values to be used as class boundaries')
		}
		minimum <- min(data, na.rm=TRUE)
		maximum <- max(data, na.rm=TRUE)
		method <- match.arg(method, c("quantile", "equal"))
		if(method == "quantile"){
			classBoundaries <- quantile(data, probs=cumsum(rep(1/classBoundaries, classBoundaries-1)), na.rm=TRUE, names = FALSE)
			classBoundaries <- c(minimum, classBoundaries, maximum)
			if(any(duplicated(classBoundaries))){stop('Non unique quantile separators (a single value may cover a substantial \n  fraction of the data). Please specify a vector of class boundaries instead.')}
		} 
		if(method == "equal"){
			intervalSize <- (maximum - minimum) / classBoundaries
			classBoundaries <- minimum + cumsum(rep(intervalSize, classBoundaries-1))
			classBoundaries <- c(minimum, classBoundaries, maximum)
		}
	} else if(!is.null(classStates)){
		if(!identical(classStates, unique(classStates))){
			stop('Non unique states defined')
		}
		if((length(classBoundaries)-1) != length(classStates)){
			stop('Number of bins must match the number of states')
		}
	}
	if( identical(classBoundaries, sort(classBoundaries)) == FALSE ){
		stop('"classBoundaries" must be provided from lowest to highest')
	}
	minimum <- classBoundaries[1]
	maximum <- classBoundaries[length(classBoundaries)]
	discreteData <- findInterval(data, classBoundaries, rightmost.closed=TRUE)
	#discreteData[which(data == maximum)] <- length(classBoundaries) - 1  #Fix max value exclusion from findInterval
	discreteData[discreteData == 0 | discreteData == length(classBoundaries)] <- NA  #Remove extra classes, out of boundaries

	breaks <- classBoundaries
	minimum <- ifelse(minimum == -Inf, min(data, na.rm=TRUE), minimum)
	maximum <- ifelse(maximum == Inf, max(data, na.rm=TRUE), maximum)
	breaks[c(1, length(breaks))] <- c(minimum, maximum)
	midValues <- sapply(1:(length(breaks)-1), function(x) {(breaks[x] + breaks[x+1])/2})
	if(!is.null(classStates)){
		discreteData <- classStates[discreteData]
	} else {
		classStates <- as.character(1:length(midValues))
	}
	return(list(discreteData=discreteData, classBoundaries=classBoundaries, 
		midValues=midValues, classStates=classStates))
}


#' bulkDiscretize
#'
#' Discretize n rasters in bulk, by using parallel processing
#' @param \code{formattedLst}
#' @param \code{xy}	A matrix of coordinates.
#' @keywords
#' @return
#' @author
#' @seealso
#' @references
#' @examples
#' function()
#' @export
bulkDiscretize <- function(formattedLst, xy){
	extractValuesByMask <- extractValuesByMask # Trick to be used  to pass function until package is not ready
	dataDiscretize <- dataDiscretize # Trick to be used to pass function until package is not ready
	splittedData <- split(as.data.frame(xy), (seq(nrow(xy))-1) %/% (nrow(xy)/(detectCores()-1)) )
	foreach(i = 1:length(splittedData), .combine=rbind, .packages='raster') %dopar% {
		df <- lapply(names(formattedLst), function(x){
			rst <- formattedLst[[x]]$Raster
			ex <- extractValuesByMask(rst, as.matrix(splittedData[[i]]))
			if(formattedLst[[x]]$Categorical == TRUE){
				formattedLst[[x]]$States[match(ex, formattedLst[[x]]$ClassBoundaries)]
			} else {
				dataDiscretize(ex, formattedLst[[x]]$ClassBoundaries, formattedLst[[x]]$States)[[1]]
			}
		})
		names(df) <- names(formattedLst)
		as.matrix(as.data.frame(df))
	}
}

#' netQuery
#' @title Query network
#'
#' @description This function queries the Bayesian network and returns the probabilities for each state of the target node. Available input variables are set as evidence.
#' @param \code{network}	object of class "grain". The Bayesian network.
#' @param \code{target}	character. The node of interest to be modelled and mapped.
#' @param \code{evidence}	matrix. Named columns are the known input variables; in rows are the discrete states associated to them for each record (NA allowed).
#' @param \code{...}	optional fixed state (i.e. evidence) for one or more nodes, e.g. in the case of constant variables.
#' @keywords
#' @return	A matrix of probabilities is returned; columns are the target node states and rows are the probabilities associated to each record of \code{evidence} .
#' @author
#' @seealso
#' @references
#' @examples
#' data(bnspatial)
#' net <- loadNetwork('LandUseChange.net')
#' netQuery(net, '', )
#' @export
netQuery <- function(network, target, evidence, ...){
	evidence <- cbind(evidence, ...)
	nms <- colnames(evidence)
	fixed <- nms[duplicated(nms)]
	if(length(fixed) > 0){
		for(i in fixed){
			fix <- max(which(nms == i))
			evidence[, nms == i] <- evidence[, fix]
			evidence <- evidence[,-fix]
		}
	}
	inputNodes <- colnames(evidence)
	if(any(inputNodes %in% network$universe$nodes == FALSE)){
		print(inputNodes[!inputNodes %in% network$universe$nodes])	
		stop('One or more nodes not found in the network, please check names.')
	}
	# Create single codes to identify all existing combinations of variables state
	# Codes are preferred as character type instead of numeric, although performance may be slightly affected
	key <- as.factor(evidence)
	evidenceCoded <- matrix(as.integer(key), nrow = nrow(evidence), ncol= ncol(evidence))
	uniqueCodes <- 1:(length(levels(key))+1) # Add an index for NAs
	key <- c(levels(key), NA) # Add NA to lookup vector
	evidenceCoded[is.na(evidenceCoded)] <- length(key)
	singleCodes <- apply(evidenceCoded, 1, function(x) {paste(x, collapse="")})
	uniCodes <- unique(singleCodes)
	# Query the network only once for each identified combinations, then append results to all corresponding cases
	evidenceSingle <- as.matrix(evidence[match(uniCodes, singleCodes), ])
	probs <- apply(evidenceSingle, 1, function(x){
		if(all(is.na(x))){
			as.numeric(querygrain(network)[[target]])
		} else {
			as.numeric(querygrain(setEvidence(network, inputNodes, x)) [[target]])
		}
	})
	probs <- t(probs)[match(singleCodes, uniCodes), ]
	colnames(probs) <- network$universe$levels[[target]]
	return(probs)
}

#' netParallelQuery
#' 
#' This function queries the bayesian network as done by \code{netQuery} by using parallel processing and splitting data into chunks.
#' @param \code{network}	object of class "grain". The Bayesian network.
#' @param \code{target}	character. The node of interest to be modelled and mapped.
#' @param \code{evidence}	
#' @param \code{cores}
#' @param \code{...}	optional fixed state (i.e. evidence) for one or more nodes, e.g. in the case of non-spatial variables which are equal everywhere.
#' @keywords
#' @return
#' @author
#' @seealso
#' @references
#' @examples
#' function()
#' @export
netParallelQuery <- function(network, target, evidence, cores=(detectCores()-1) , ...){
	evidence <- cbind(evidence, ...)
	netQuery <- netQuery # Trick to be used  to pass function until package is not ready
	splittedData <- split(as.data.frame(evidence), (seq(nrow(evidence))-1) %/% (nrow(evidence)/cores) )
	splittedData <- lapply(1:length(splittedData), function(x){as.matrix(splittedData[[x]], ncol=ncol(evidence))})	
	foreach(i = 1:length(splittedData), .combine=rbind, .packages="gRain") %dopar% {
		netQuery(network=network, target=target, evidence=splittedData[[i]])
	}
}


#' mapTarget
#' @title Map target node
#'
#' @description This function creates make the spatial outputs for the target node
#' FIX COORD.REF. OUTPUT RASTERS
#' FIX OUTPUT
#' @param \code{target}	character. The node of interest to be modelled and mapped.
#' @param \code{statesProb}
#' @param \code{what} The required output. Any of these values are valid:
#' \itemize{
#' \item{"class"} returns the most likely states.
#' \item{"entropy"} calculates the Shannon index and returns the entropy given the evidence.
#' \item{"probability"} returns an object for each state of the target node, with associated probability.
#' \item{"expected"} only valid for continuous target nodes, when \code{midValues} argument is provided. The expected value for the target node (see Details)
#' \item{"variation"} returns the coefficient of variation, as a measure of uncertainty.
#' }
#' @param \code{context}
#' @param \code{midVals}
#' @param \code{targetState}
#' @param \code{spatial}
#' @param \code{exportRaster}
#' @param \code{path}
#' @keywords
#' @return	a list of objects, one for each item required in \code{what} argument. If \code{spatial = TRUE} a list of rasters of class "RasterLayer" are returned, if FALSE a list of vectors. 
#' @details The expected value is calculated by summing the mid values of target node states weighted by their probability: \code{p1 * midVal_1 + p2 * midval_2 + ... + pn * midval_n}
#' @author
#' @seealso
#' @references
#' @examples
#' function()
#' @export
mapTarget <- function(target, statesProb, what=c("class", "entropy", "probability"), context, midVals=NULL, targetState=NULL, spatial=TRUE, exportRaster=FALSE, path=NULL){
	what <- match.arg(what, c("class", "entropy", "probability", "expected", "variation"), several.ok = TRUE)
	if(exportRaster == TRUE) {
		if(is.null(path)){
			path <- paste(getwd(), '/', sep='')
		}
	}
	if(spatial == TRUE){
		if(class(context) == 'RasterLayer'){
			id <- context
			id[] <- 1:length(id)
			id <- getValues(id)[!is.na(getValues(context))]
			context[] <- NA
		} else { 
			stop('"context" must be an object of type "RasterLayer" as from raster::raster() function')
		}
	}
	whatList <- list()
	if('class' %in% what){
		Class <- as.factor(apply(statesProb, 1, function(x){colnames(statesProb)[which.max(x)]}) )
		if(spatial == TRUE){
			Class <- match(Class, colnames(statesProb))
			context[id] <- Class
			Class <- context
			keyLegend <- data.frame(colnames(statesProb), 1:length(colnames(statesProb)))
			names(keyLegend) <- c(target, 'ID')
			if(exportRaster == TRUE){
				writeRaster(Class, paste(path, target, '_Class.tif', sep=''), overwrite=TRUE, datatype='INT2S')
				write.csv(keyLegend, paste(path, target, '_ClassKey.csv', sep=''), row.names = FALSE)
			} else {
				print(keyLegend)
			}
		}
		whatList$Class <- Class
	}
 	if('expected' %in% what | 'variation' %in% what){
		if(is.null(midVals)){
			warning('Could not calculate the expected value (nor coefficient of variation) as either target node seems to be categorical or mid-values for each states of target node were not provided.')
		} else {
			Expected <- .expectedValue(statesProb, midVals)
			if('variation' %in% what){
				uncertainty <- sapply(1:length(Expected), function(x) {sqrt(sum((midVals - Expected[x])^2 * statesProb[x,]))})
				Variation <- uncertainty / Expected
				if(spatial == TRUE){ 
					context[id] <- Variation
					Variation <- context
					if(exportRaster == TRUE){
						writeRaster(Variation, paste(path, target, '_CoeffVariation.tif', sep=''), overwrite=TRUE)
					}
				}
				whatList$CoeffVariation <- Variation			
			}
			if('expected' %in% what){
				if(spatial == TRUE){ 
					context[id] <- Expected
					Expected <- context
					if(exportRaster == TRUE){
						writeRaster(Expected, paste(path, target, '_ExpectedValue.tif', sep=''), overwrite=TRUE)
					}
				}
				whatList$ExpectedValue <- Expected
			}
		}
	}
	if('entropy' %in% what){
		Entropy <- apply(statesProb, 1, function(x){-x %*% log(x)} )
		if(spatial == TRUE){ 
			context[id] <- Entropy
			Entropy <- context
			if(exportRaster == TRUE){
				writeRaster(Entropy, paste(path, target, '_Entropy.tif', sep=''), overwrite=TRUE)
			}
		}
		whatList$Entropy <- Entropy
	}	
	if('probability' %in% what){
		if(is.null(targetState)){
			targetState <- colnames(statesProb)
		}
		Probability <- lapply(targetState, function(x) {statesProb[, x]} )
		if(spatial == TRUE){
			Probability <- lapply(1:length(Probability), function(x) {context[id] <- Probability[[x]]; return(context)})	
		}
		names(Probability) <- targetState
		whatList$Probability <- Probability
		if(spatial == TRUE & exportRaster == TRUE){
			lapply(1:length(Probability), function(x) {writeRaster(Probability[[x]], paste(path, target, '_Probability_', targetState[x], '.tif', sep=''), overwrite=TRUE)})
		}
	}
	if(spatial == FALSE){
		xy <- xyFromCell(context, id)
		whatList <- cbind(id, xy, as.data.frame(whatList))
	}
	return(whatList)
}

.expectedValue <- function(statesProb, midVals) {
	return(apply(statesProb, 1, function(x){x %*% midVals}))
}


#' bnSpatialize
#' @title Spatialize the Bayesian network
#'
#' @description This function wraps most bnspatial package functions to ease the spatial implementation of Bayesian networks with minimal user interaction.
#' @param \code{network}	The Bayesian network. Must be provided as character (the path to a ".net" file to be imported), or as object of class "grain".  
#' @param \code{target}	character. The node of interest to be modelled and mapped. Default set to NULL, otherwise the network will be compiled based on it for faster querying.
#' @param \code{spatialData}
#' @param \code{lookUp}
#' @param \code{msk}
#' @param \code{outputs}
#' @param \code{midVals}
#' @param \code{targetState}
#' @param \code{spatial}
#' @param \code{mcores}
#' @param \code{exportRaster}
#' @param \code{path}
#' @param \code{...}
#' @keywords
#' @return
#' @author
#' @seealso
#' @references
#' @examples
#' function()
#' @export
bnSpatialize <- function(network, target, spatialData, lookUp, msk=NULL, outputs=c("class", "entropy"), midVals=NULL, targetState=NULL, spatial=TRUE, mcores=FALSE, exportRaster=FALSE, path=NULL, ...){
	installMissingPackages(mcores)
	network <- loadNetwork(network=network, target=target)

	## Load table with class boundaries, if available (otherwise make a list with node name and associated vector of class boundaries)
	if(class(lookUp) == 'character' & length(lookUp) == 1){
		classes <- importClasses(lookUp)
	} else if (class(lookUp) == 'list' & length(lookUp)[[1]] == 3 & class(lookUp)[[1]] == 'list'){
		classes <- lookUp
	} else {
		stop('Check "lookUp": must be a text file or a formatted list as output from "setClasses" and "importClasses" functions')
	}

	## Load input spatial data and corresponding nodes and states into a list
	if(class(spatialData) != 'character' | length(spatialData) != length(classes)){
		stop('Check "spatialData": must be a vector of file names of length equal to the number of corresponding nodes')
	}
	spatialDataList <- linkNodeRasterList(spatialData=spatialData, network=network, classification=classes)

	## Load or create mask
	msk <- AOI(spatialDataList, msk=msk) 

	## Identify, index and get coordinates of valid cells (= non NA) from area of interest/mask
	id <- msk
	id[] <- 1:length(id)
	id <- getValues(id)[!is.na(getValues(msk))]
	xy <- xyFromCell(msk, id)

#	## Remove spatial data that was set as evidence in the ellipsis (...)
#	if(length(list(...)) > 0){
#	ls() 
#		if(ls()... %in% names(spatialDataList)){
#			spatialDataList = spatialDataList[-which(... %in% names(spatialDataList))]
#		}
#	}

	## Extract data from locations, discretize and query Bayesian network
	if(mcores==TRUE){
		cl <- makePSOCKcluster(detectCores()-1)
		registerDoParallel(cl)
		tab <- bulkDiscretize(spatialDataList, xy)
		probs <- netParallelQuery(network, target, tab, ...)
		stopCluster(cl); gc()
	} else {
		tab <- matrix(nrow=nrow(xy), ncol=length(spatialDataList))
		colnames(tab) <- names(spatialDataList)
		for(nm in colnames(tab)) {
			rst <- spatialDataList[[nm]]$Raster
			ex <- extractValuesByMask(rst, xy)
			if(spatialDataList[[nm]]$Categorical == TRUE){
				tab[, nm] <- spatialDataList[[nm]]$States[match(ex, spatialDataList[[nm]]$ClassBoundaries)]
			} else {
				tab[, nm] <- dataDiscretize(ex, spatialDataList[[nm]]$ClassBoundaries, spatialDataList[[nm]]$States)[[1]]
			}
		}
		probs <- netQuery(network, target, tab, ...)
	}
	mapTarget(target=target, statesProb=probs, what=outputs, context=msk, midVals=midVals, spatial=spatial, targetState=targetState, exportRaster=exportRaster, path=path)
}

