### R wrapper to implement Bayesian Networks on raster data 
### Author: Dario Masante - dmasan@ceh.ac.uk (dario.masante@gmail.com)
### April 2016

## A crop yield model scenario simulation at the landscape scale, using continuous data, 
## where fertilisers application and irrigated are known spatial inputs. 
## Temperature is provided as, while Rainfall is an unknown variable

#' @name setClasses
#' @title Set classes or intervals
#' 
#' @description Functions \code{setClasses} and \code{importClasses} return a formatted list from given arguments, to be used for the Bayesian network and input spatial variables integration and error checking.
#' For \code{setClasses} a vector with node names and a list of vectors for both states of nodes and (optional) their boundaries in the spatial data 
#' must be provided, in the right order.
#' For \code{importClasses} a formatted text file must be provided (see below).
#' @aliases importClasses
#' @rdname setClasses
#' @param classFile	character. A text file where for each input variable associated to a node (see below) three lines are specified as follows: 
#' the first one indicates the node name, as in the Bayesian network; the second indicates the states associated with such variable, as they are in the Bayesian network;
#' the third one contains the values associated to each state in the spatial data (for discrete variables) or the class boundaries dividing the states (for continuous variables), including minimum and maximum
#' @param nodes character. The nodes for which some information is known and available as spatial data
#' @param states A list of characters. The states associated to each of the nodes (order must match \code{nodes} names)
#' @param classBoundaries A list of numeric. The boundary values dividing nodes into corresponding states. For categorical variables the raster values associated to node states. Must be sorted in ascending order.
#' @keywords
#' @return A formatted list, specifying states break values for continuous nodes and integer values for categorical nodes.
#' @details As a reference for the formatting of the text file:
#' \strong{First line}: the node name.\cr
#' \strong{Second line}: the node states, comma separated (spaces allowed). \cr
#' \strong{Third line}: intervals from the spatial data associated to the states (integer values for discrete data and class boundaries, including endpoints, for continuous data). The same order as node states is required.\cr
#' 
#' For example:
#' 
#' \code{CurrentLULC} \cr
#' \code{forest,other,arable} \cr
#' \code{2, 1, 3} \cr
#' \code{Slope} \cr
#' \code{flat, moderate, steep} \cr
#' \code{-Inf, 1, 7, Inf} \cr
#' \code{LegalStatus} \cr
#' \code{public, private, protected} \cr
#' \code{4, 3, 1 }
#' @author
#' @seealso \code{\link{dataDiscretize}}
#' @references
#' @examples
#' importClasses('ConwyClasses.txt')
#' 
#' ### Same as:
#'
#' setClasses(c('Slope', 'CurrentLULC', 'LegalStatus'), list(c('flat', 'moderate', 'steep'), 
#' c('forest', 'arable', 'other'), c('public', 'private', 'protected')),
#' list(c(-Inf, 0, 5, Inf), c(2, 3, 1), (c(4, 3, 1))))
#' 
#' @export
setClasses <- function(nodes, states, classBoundaries){
	lst <- vector('list', length = length(nodes))
	names(lst) <- nodes
	for(i in 1:length(names(lst)) ){
		if(!identical(states[[i]], unique(states[[i]]))){
			print(states[[i]])
			stop('Non unique node state defined')
		}		
		lst[[i]]$States <- states[[i]]
		if(!identical(classBoundaries[[i]], unique(classBoundaries[[i]]))){
			print(classBoundaries[[i]])
			stop('Non unique "classBoundaries" defined')
		}
		if((length(classBoundaries[[i]]) - length(states[[i]])) %in% c(0, 1)){
			categorical <- ifelse(length(classBoundaries[[i]]) == length(states[[i]]), TRUE, FALSE)
		} else {
			stop('Number of classes does not match number of states. Also, for non categorical data 
				minimum and maximum boundaries must be set (-Inf and Inf allowed).')
		}
		lst[[i]]$ClassBoundaries <- classBoundaries[[i]]
		lst[[i]]$Categorical <- categorical
		if( identical(classBoundaries[[i]], sort(classBoundaries[[i]])) == FALSE & categorical == FALSE){
			print(classBoundaries[[i]])
			stop('"classBoundaries" for non categorical data must be sorted from lowest to highest')
		}
	}
	return(lst)
}

#' @rdname setClasses
#' @export
importClasses <- function(classFile){
	if(class(classFile) != 'character' | length(classFile) != 1){
		stop('Argument "classFile" must be a character vector of length one')
	}
	nodes <- vector()
	states <- list()
	classBoundaries <- list()
	classTxt <- scan(classFile, character(0), sep = "\n")
	for(i in seq(1, length(classTxt), by=3)){
		node <- classTxt[i]
		nodes <- c(nodes, node)
		state <- gsub(" ", "", unlist(strsplit(classTxt[i+1], ",")))
		states[[node]] <- state
		class <- as.numeric(gsub(" ", "", unlist(strsplit(classTxt[i+2], ","))))
		classBoundaries[[node]] <- class
	}
	setClasses(nodes=nodes, states=states, classBoundaries=classBoundaries)
}


#' @name linkNodeRaster
#' @title Link nodes to spatial data
#' 
#' @description \code{linkNodeRaster} links a node of the Bayesian network to its corresponding spatial dataset (in raster format), returning a list of objects, including the spatial data and relevant information about the node.\cr
#' \code{linkNodeRasterList} operates on multiple rasters and nodes.\cr
#' ISSUE: FIX ORDER OF NODES BETWEEN CLASSIFICATION AND SPATIAL DATA
#' @aliases linkNodeRasterList
#' @param layer	character. The raster file of spatial data corresponding to a network node. 
#' @inheritParams loadNetwork
#' @param node character. A network node associated to the file in \code{layer} argument
#' @param intervals A list of numeric vectors. For categorical variables the raster values associated to each state of the node, for continuous variables the boundary values dividing into the corresponding states.
#' @param categorical logical. Is the node a categorical variable? Default is NULL.
#' @param verbose logical. If \code{verbose = TRUE} a summary of class boundaries and associated nodes and data will be printed to screen for quick checks.
#' @param spatialData character. The raster files corresponding to nodes 
#' @param lookup character or a formatted list. This argument can be provided as path to a comma separated file or a formatted list (see \code{\link{setClasses}} )
#' @keywords
#' @return \code{linkNodeRaster} returns a list of objects, including the spatial data and summary information about each node.\cr
#' \code{linkNodeRasterList} returns a list of lists. Each element of the list includes the spatial data and summary information for each of the input nodes.
#' @details In future releases, this function may be rewritten to provide an S4 object instead of a list.
#' @author
#' @seealso \code{dataDiscretize}; \code{\link{setClasses}}
#' @references
#' @examples
#' ## Load the Bayesian network
#' linkNodeRaster('ConwyLULC.tif', 'LandUseChange.net', 'CurrentLULC', c(2, 3, 1))
#'
#' ## Load the Bayesian network, the spatial data and the classification/discretisation lookup list
#' net <- loadNetwork('LandUseChange.net')
#' spatialData <- c('ConwyLULC.tif','ConwySlope.tif','LegalStatus.tif')
#' lookup <- importClasses('ConwyClasses.txt')
#' linkNodeRasterList(spatialData, net, lookup, verbose = FALSE)
#' @export
linkNodeRaster <- function(layer, network, node, intervals, categorical=NULL, verbose=TRUE){
    network = loadNetwork(network=network)
	# Check correspondence of node and states names between lookup list and network
	checkName <- node %in% names(network$universe$levels)
	if(checkName == FALSE){
		stop('A node name provided does not match any node names from the network')		
	}
	states <- network$universe$levels[[node]]
	# Check correspondence of number of states and intervals
#	if(!is.null(intervals)) {
	if(!identical(intervals, unique(intervals))){
		stop('Non unique intervals defined')
	}
	delta <- length(intervals) - length(states)
	if(! delta %in% c(0, 1)){
		stop('Number of classes does not match number of states.')
	}
	if(!is.null(categorical)){
		if(categorical == TRUE & delta != 0) {
			stop('Number of classes does not match number of states.')
		} else if(categorical == FALSE & delta != 1) {
			stop('Number of intervals does not match number of states. For non categorical data 
				minimum and maximum boundaries must be set (-Inf and Inf allowed).')
		}
	}
	categorical <- ifelse(delta != 0, FALSE, TRUE)
	if( identical(intervals, sort(intervals)) == FALSE & categorical == FALSE){
		stop('"intervals" must be sorted from lowest to highest')
	}
	r <- raster::raster(layer)
	if(categorical == TRUE){
		v <- as.factor(raster::getValues(r))
		if(is.null(intervals)){
			intervals <- as.numeric(levels(v))
			warning('For categorical data check classes integer value and corresponding states.
				If not matching as look up list should be provided (function "setClasses")
				or modified from current list.')
		} else {
			if(identical(as.numeric(levels(v)), sort(intervals)) == FALSE){
				stop('Integer values in categorical data do not match categories provided')
			}
		}
	} 
	
	lst <- list(list(States = states, Categorical = categorical, ClassBoundaries = intervals, FilePath = layer, Raster = r))
	names(lst) <- node
	if(verbose == TRUE){
		writeLines(c(paste('\n"', node, '"', ' points to:', sep=''), 
			paste(' -> ', layer, '\n'), 
			'With states:', 
			paste(states, collapse='    '), 
			ifelse(is.null(categorical), '', ifelse(categorical == TRUE, '\nRepresented by integer values:', '\nDiscretized by intervals:')), 
			paste(intervals, collapse= ' <-> '))
		)
		writeLines('----------------------------------')
	}
	return(lst)
}

#' @rdname linkNodeRaster
#' @export
linkNodeRasterList <- function(spatialData, network, lookup, verbose=TRUE){
	if(class(lookup) == 'character' & length(lookup) == 1){
		lookup <- importClasses(lookup)
	}
	if(length(spatialData) != length(lookup)){
		stop('Spatial data files do not match the number of nodes provided in the look up list')
	}
    network = loadNetwork(network=network)
	# Check correspondence of node and states names between lookup list and network
	# then iterate through the nodes and append to summary list
	lst <- list()
	for(nm in names(lookup)){
		checkStates <- lookup[[nm]]$States %in% network$universe$levels[[nm]]
		if(any(checkStates == FALSE)){
			stop(paste("Node states provided from the look up list do not match \n node states from the network: \n \n'", 
				lookup[[nm]]$States[!checkStates], "' missing from network node", nm))
		}
		Categorical <- lookup[[nm]]$Categorical
		if(Categorical == TRUE){
			sortedClasses <- match(network$universe$levels[[nm]],lookup[[nm]]$States)
			ClassBoundaries <- lookup[[nm]]$ClassBoundaries[sortedClasses]
		} else {
			ClassBoundaries <- lookup[[nm]]$ClassBoundaries
		}
		lst[nm] <- linkNodeRaster(spatialData[ names(lookup) == nm ], network=network, node=nm, 
			intervals=ClassBoundaries, categorical=Categorical, verbose=verbose)
	}
	return(lst)
}


#' @name AOI
#' @title Area Of Interest (AOI)
#'
#' @description This function creates a raster defining the area of interest, by unioning the input rasters or taking a user defined mask as reference.
#' Resolution and extent are set equal to those of the mask raster (\code{msk}) when specified, otherwise
#' to the finest resolution among input spatial data and as the union of extents of input data.
#' @param spDataLst a formatted list of input rasters formatted character. The raster file corresponding to node 
#' @param msk a character or an object of class "RasterLayer". The reference raster to be used as mask. 
#' All model outputs will have the same resolution and same extent as this raster. All locations with no data (i.e. NA) cells 
#' in this raster will be ignored as well.
#' @param mskSub vector. The values from \code{msk} which should be retained for building the area of interest
#' @keywords
#' @return an object of class RasterLayer, where valid cells (i.e. the area of interest) have value 1, NA otherwise.
#' @author
#' @seealso \code{\link{extractValuesByMask}}
#' @references
#' @examples
#' ## Load network, spatial data and lookup list:
#' 
#' net <- loadNetwork('LandUseChange.net')
#' spatialData <- c('ConwyLULC.tif', 'ConwySlope.tif', 'LegalStatus.tif')
#' lookup <- importClasses('ConwyClasses.txt')
#' spDataLst <- linkNodeRasterList(spatialData, net, lookup, verbose = FALSE)
#' AOI(spDataLst)
#' 
#' ## Plot output map
#' plot(AOI(msk='ConwyLULC.tif'))
#' 
#' m <- raster('ConwyLULC.tif')
#' plot(AOI(msk=m, mskSub=c(2,3)))
#' @export
AOI <- function(spDataLst=NULL, msk=NULL, mskSub=NULL){
	if(is.null(msk)){
		if(is.null(spDataLst)) {
			stop('Must provide the area of interest or at least one data layer')
		}
		r <- spDataLst[[1]]$Raster
		ext <- raster::extent(r)
		cellSizeX <- raster::res(r)[1]
		cellSizeY <- raster::res(r)[2]
		for(i in 1:length(spDataLst)){
			r <- spDataLst[[i]]$Raster
			ext <- raster::union(ext, raster::extent(r) )
			cellSizeX <- ifelse(cellSizeX > raster::res(r)[1], raster::res(r)[1], cellSizeX)
			cellSizeY <- ifelse(cellSizeY > raster::res(r)[2], raster::res(r)[2], cellSizeY)
		}
		msk <- raster::raster(xmn=ext[1], xmx=ext[2], ymn=ext[3], ymx=ext[4], ext=ext, resolution=c(cellSizeX, cellSizeY), vals = 1)
	} else {
		if(class(msk) != 'RasterLayer'){
			msk <- raster::raster(msk)
		}
		id <- msk
		id[] <- 1:length(id)
		mskVals = raster::getValues(msk)
		if(!is.null(mskSub)){
			id <- raster::getValues(id)[!is.na(mskVals) & mskVals %in% mskSub]
		} else {
			id <- raster::getValues(id)[!is.na(mskVals)]
		}
		msk[]<- NA
		msk[id] <- 1
	}
	return(msk)
}


#' extractValuesByMask
#' @title Extract raster values by mask
#' DEBUG!! NA missed
#' @description This function extracts the values from a given input raster based on a mask, by harmonizing resolution and extent with it.
#' @param rast an object of class "RasterLayer". The raster from which data will be extracted
#' @param msk an object of class "RasterLayer" (package \href{https://cran.r-project.org/web/packages/raster/index.html}{raster}) 
#' or a two column matrix of coordinates. The reference raster (or coordinates) to be used as mask for extraction.
#' @keywords
#' @return integer. The cells identifier (as from raster package)
#' @author
#' @references
#' @examples
#' mask <- AOI(msk='ConwyLULC.tif', mskSub=c(2,3))
#' r <- raster('ConwySlope.tif')
#' head( extractValuesByMask(r, msk=mask)) 
#' @export
extractValuesByMask <- function(rast, msk){
	if(class(rast) != 'RasterLayer'){
		stop('"rast" argument must be an object of "RasterLayer" class.')
	}
	if(class(msk) == 'RasterLayer'){
		id <- msk
		id[] <- 1:length(id)
		id <- raster::getValues(id)[!is.na(raster::getValues(msk))]
		xy <- raster::xyFromCell(msk, id)
		cells <- raster::cellFromXY(rast, xy[, 1:2])
	} else if (class(msk) == 'matrix'){
		cells <- raster::cellFromXY(rast, msk[, 1:2])
	} else {
		stop('"msk" argument must be either an object of RasterLayer class or \n a matrix of coordinates "x" and "y"')
	}
	return( raster::getValues(rast)[cells] )
}

#' dataDiscretize
#' @title Discretize data
#'
#' @description These functions discretize continuous input data into classes. Classes can be defined 
#' by the user or, if the user provides the number of expected classes, calculated 
#' from quantiles (default option) or by equal intervals. \cr
#' \code{dataDiscretize} processes a single variable at a time, provided as vector, \cr
#' \code{bulkDiscretize} discretizes multiple input rasters, by using parallel processing.
#' @rdname dataDiscretize
#' @aliases bulkDiscretize
#' @param data numeric vector. The continuous data to be discretized.
#' @param classBoundaries numeric vector. Interval boundaries to be used for data discretization. 
#' Minimum and maximum are required ( \code{-Inf} or \code{Inf} are allowed, but to calculate the 
#' class mid values the minimum and maximum will be taken from the data), or a single integer to 
#' indicate the number of classes to split by quantiles or equal intervals.
#' @param classStates vector. The state labels to be assigned to the discretised data.
#' @param method character. What splitting method should be used? This argument does not apply if 
#' user defined values are passed to \code{classBoundaries}
#' \itemize{
#' \item{\code{quantile} (default option) splits data into quantiles. }
#' \item{\code{equal} splits data into equally sized interval based on minimum and maximum values in the data. }}
#' @param formattedLst A formatted list as returned by \code{\link{linkNodeRaster}} and \code{\link{linkNodeRasterList}}
#' @param xy A matrix of coordinates.
#' @keywords
#' @return \code{dataDiscretize} returns a named list of 4 vectors: 
#' \itemize{
#' \item{\code{$discreteData} the discretized data, labels are applied accordingly if \code{classStates} argument is provided }
#' \item{\code{$classBoundaries} the class boundaries, i.e. values defining the classes }
#' \item{\code{$midValues} the mid point for each class (the mean of its lower and upper boundaries) }
#' \item{\code{$classStates} the labels assigne to each class }} \cr
#' \code{bulkDataDiscretize} returns a matrix: in columns each node associated to input spatial data, 
#' in rows their discretized values at coordinates specified by \code{xy}.
#' @details
#' @author
#' @seealso
#' @references
#' @examples
#' s <- runif(100)
#'
#' #Split by user defined values. Values out of boundaries are set to NA:
#' dataDiscretize(s, classBoundaries=c(0.2, 0.5, 0.8)) 
#'
#' #Split by quantiles (default):
#' dataDiscretize(s, classStates=c('a', 'b', 'c'))
#'
#' #Split by equal intervals:
#' dataDiscretize(s, classStates=c('a', 'b', 'c'), method="equal")
#'
#' ## When -Inf and Inf are provided as external boundaries, \code{$midValues} of outer classes\cr
#' ## are calculated on the minimum and maximum values:
#' dataDiscretize(s, classBoundaries=c(0, 0.5, 1), classStates=c("first", "second"))
#' dataDiscretize(s, classBoundaries=c(-Inf, 0.5, Inf), classStates=c("first", "second"))
#' @export
dataDiscretize <- function(data, classBoundaries=NULL, classStates=NULL, method="quantile"){
	if(is.null(classBoundaries)){
		if(is.null(classStates)){ 
			stop('Must provide either "classBoundaries", "classStates" or both') 
		} else {
			classBoundaries <- length(classStates)
		}
	}
	if(length(classBoundaries) == 1){
		if(!is.null(classStates) & classBoundaries != length(classStates)){
			stop('Number of bins must match the number of states')
		}
		if(classBoundaries < 2 | abs(classBoundaries - round(classBoundaries)) > 0 ){
			stop('"classBoundaries" must be an integer greater than 1, \n 
				or a vector of values to be used as class boundaries')
		}
		minimum <- min(data, na.rm=TRUE)
		maximum <- max(data, na.rm=TRUE)
		method <- match.arg(method, c("quantile", "equal"))
		if(method == "quantile"){
			classBoundaries <- quantile(data, probs=cumsum(rep(1/classBoundaries, classBoundaries-1)), na.rm=TRUE, names = FALSE)
			classBoundaries <- c(minimum, classBoundaries, maximum)
			if(any(duplicated(classBoundaries))){stop('Non unique quantile separators (a single value may cover a substantial \n  fraction of the data). Please specify a vector of class boundaries instead.')}
		} 
		if(method == "equal"){
			intervalSize <- (maximum - minimum) / classBoundaries
			classBoundaries <- minimum + cumsum(rep(intervalSize, classBoundaries-1))
			classBoundaries <- c(minimum, classBoundaries, maximum)
		}
	} else if(!is.null(classStates)){
		if(!identical(classStates, unique(classStates))){
			stop('Non unique states defined')
		}
		if((length(classBoundaries)-1) != length(classStates)){
			stop('Number of bins must match the number of states')
		}
	}
	if( identical(classBoundaries, sort(classBoundaries)) == FALSE ){
		stop('"classBoundaries" must be provided from lowest to highest')
	}
	minimum <- classBoundaries[1]
	maximum <- classBoundaries[length(classBoundaries)]
	discreteData <- findInterval(data, classBoundaries, rightmost.closed=TRUE)
	#discreteData[which(data == maximum)] <- length(classBoundaries) - 1  #Fix max value exclusion from findInterval
	discreteData[discreteData == 0 | discreteData == length(classBoundaries)] <- NA  #Remove extra classes, out of boundaries

	breaks <- classBoundaries
	minimum <- ifelse(minimum == -Inf, min(data, na.rm=TRUE), minimum)
	maximum <- ifelse(maximum == Inf, max(data, na.rm=TRUE), maximum)
	breaks[c(1, length(breaks))] <- c(minimum, maximum)
	midValues <- sapply(1:(length(breaks)-1), function(x) {(breaks[x] + breaks[x+1])/2})
	if(!is.null(classStates)){
		discreteData <- classStates[discreteData]
	} else {
		classStates <- as.character(1:length(midValues))
	}
	return(list(discreteData=discreteData, classBoundaries=classBoundaries, 
		midValues=midValues, classStates=classStates))
}

#' @rdname dataDiscretize
#' @export
bulkDiscretize <- function(formattedLst, xy){
	extractValuesByMask <- extractValuesByMask # Trick to be used  to pass function until package is not ready
	dataDiscretize <- dataDiscretize # Trick to be used to pass function until package is not ready
	splittedData <- split(as.data.frame(xy), (seq(nrow(xy))-1) %/% (nrow(xy)/(parallel::detectCores()-1)) )
	foreach::foreach(i = 1:length(splittedData), .combine=rbind, .packages='raster') %dopar% {
		df <- lapply(names(formattedLst), function(x){
			rst <- formattedLst[[x]]$Raster
			ex <- extractValuesByMask(rast=rst, msk=as.matrix(splittedData[[i]]))
			if(formattedLst[[x]]$Categorical == TRUE){
				formattedLst[[x]]$States[match(ex, formattedLst[[x]]$ClassBoundaries)]
			} else {
				dataDiscretize(ex, formattedLst[[x]]$ClassBoundaries, formattedLst[[x]]$States)[[1]]
			}
		})
		names(df) <- names(formattedLst)
		as.matrix(as.data.frame(df))
	}
}


#' @name netQuery
#' @title Query the Bayesian network
#'
#' @description This function queries the Bayesian network and returns the probabilities for each 
#' state of the target node. Available input variables are set as evidence. \cr 
#' \code{netParallelQuery} works as \code{netQuery}, but makes use of multi cores/processors facilities 
#' for big network queries, by splitting data into chunks and processing data in parallel.
#' @aliases netParallelQuery
#' @rdname netQuery
#' @inheritParams loadNetwork
#' @param target character. The node of interest to be modelled and mapped.
#' @param evidence matrix. Named columns are the known input variables; in rows are the discrete states associated to them for each record (NA allowed).
#' @param ... Additional arguments for fixing state (i.e. setting evidence) to one or more nodes, 
#' as it was known and independent from any spatial data (e.g. the case of non-spatial variables 
#' which are equal everywhere). Node name is provided as argument and the associated fixed state as 
#' character; both node and state names must be typed correctly according to what is in the network.
#' @param mc number of cores/processors to be used by \code{netParallelQuery}. By default is set to 
#' the maximum number available minus one.
#' @keywords
#' @return A matrix of probabilities: columns are the target node states and rows are the probabilities associated to each record of \code{evidence}.
#' @author
#' @seealso
#' @references
#' @examples
#' data(bnspatial)
#' net <- loadNetwork('LandUseChange.net')
#' netQuery(net, '', )
#' @export
netQuery <- function(network, target, evidence, ...){
	evidence <- cbind(evidence, ...)
	nms <- colnames(evidence)
	fixed <- nms[duplicated(nms)]
	if(length(fixed) > 0){
		for(i in fixed){
			fix <- max(which(nms == i))
			evidence[, nms == i] <- evidence[, fix]
			evidence <- evidence[,-fix]
		}
	}
	inputNodes <- colnames(evidence)
	if(any(inputNodes %in% network$universe$nodes == FALSE)){
		print(inputNodes[!inputNodes %in% network$universe$nodes])	
		stop('One or more nodes not found in the network, please check names.')
	}
	# Create single codes to identify all existing combinations of variables state
	# Codes are preferred as character type instead of numeric, although performance may be slightly affected
	key <- as.factor(evidence)
	evidenceCoded <- matrix(as.integer(key), nrow = nrow(evidence), ncol= ncol(evidence))
	uniqueCodes <- 1:(length(levels(key))+1) # Add an index for NAs
	key <- c(levels(key), NA) # Add NA to lookup vector
	evidenceCoded[is.na(evidenceCoded)] <- length(key)
	singleCodes <- apply(evidenceCoded, 1, function(x) {paste(x, collapse="")})
	uniCodes <- unique(singleCodes)
	# Query the network only once for each identified combinations, then append results to all corresponding cases
	evidenceSingle <- as.matrix(evidence[match(uniCodes, singleCodes), ])
	probs <- apply(evidenceSingle, 1, function(x){
		if(all(is.na(x))){
			as.numeric(gRain::querygrain(network)[[target]])
		} else {
			as.numeric(gRain::querygrain(gRain::setEvidence(network, inputNodes, x)) [[target]])
		}
	})
	probs <- t(probs)[match(singleCodes, uniCodes), ]
	colnames(probs) <- network$universe$levels[[target]]
	return(probs)
}

#' @rdname netQuery
#' @export
netParallelQuery <- function(network, target, evidence, mc=(parallel::detectCores()-1), ...){
    network = loadNetwork(network=network)
	evidence <- cbind(evidence, ...)
	netQuery <- netQuery # Trick to be used  to pass function until package is not ready
	splittedData <- split(as.data.frame(evidence), (seq(nrow(evidence))-1) %/% (nrow(evidence)/mc) )
	splittedData <- lapply(1:length(splittedData), function(x){as.matrix(splittedData[[x]], ncol=ncol(evidence))})	
	foreach::foreach(i = 1:length(splittedData), .combine=rbind, .packages="gRain") %dopar% {
		netQuery(network=network, target=target, evidence=splittedData[[i]])
	}
}


#' mapTarget
#' @title Map target node
#'
#' @description This function creates make the spatial outputs for the target node
#' FIX COORD.REF. OUTPUT RASTERS
#' FIX OUTPUT
#' @param target character. The node of interest to be modelled and mapped.
#' @param statesProb matrix. The probability matrix as returned by \code{\link{netQuery}} and \code{netParallelQuery}.
#' Columns are the \code{target} node states and rows each location considered from the area of interest.
#' @param what character. The required output, one or more of these values are valid:
#' \itemize{
#' \item{\code{"class"}} returns the most likely states.
#' \item{\code{"entropy"}} calculates the Shannon index and returns the entropy given the evidence.
#' \item{\code{"probability"}} returns an object for each state of the target node, with associated probability.
#' \item{\code{"expected"}} The expected value for the target node (see Details). Only valid for continuous target nodes. \code{midValues} argument must be provided.
#' \item{\code{"variation"}} returns the coefficient of variation, as a measure of uncertainty.
#' }
#' @param msk an object of class "RasterLayer". The reference raster to be used as mask. 
#' All model outputs will have the same resolution and same extent as this raster. All locations with no data (i.e. NA) cells 
#' in this raster will be ignored as well.
#' @param midvals vector of length equal to the number of states of the target node. Applies only if the target node is a continuous 
#' variable, in which case \code{midvals} must contain the mid values for each of the intervals 
#' @param targetState character. One or more states of interest from the target node. Applies only 
#' when argument \code{what} includes \code{'probability'}. Default is set to all states of the node.
#' @param spatial logical. Should the output be spatially explicit -i.e. a georeferenced mappable 
#' layer? Default is TRUE, returning a an object of class RasterLayer. If FALSE, it returns a vector 
#' of values, one for each non NA cell in \code{msk} raster.
#' @param exportRaster Logical or character. Should the spatial output be exported to a raster file? 
#' Applies only if argument \code{spatial = TRUE}. When \code{exportRaster = TRUE}, rasters will be 
#' exported in .tif format. A character specifying another format can be provided, in which case the 
#' raster will be exported in that format. Only formats listed by \link[raster]{writeFormats} are valid. 
#' @param path The directory to store output files, if \code{exportRaster=TRUE}. 
#' Default is set to the working directory \code{getwd()}.
#' @keywords
#' @return A list of objects, one for each item required in \code{what} argument. If \code{spatial = TRUE} 
#' a list of rasters of class "RasterLayer" are returned, if FALSE a list of vectors with values 
#' associated to each non NA cell in msk raster (i.e. the vectorised raster). If argument \code{exportRaster} 
#' is specified, outputs are exported to files to the directory specified in \code{path}.
#' @details The expected value is calculated by summing the mid values of target node states weighted by their probability: \cr
#' \code{p1 * midVal_1 + p2 * midval_2 + ... + pn * midval_n}
#' @author
#' @seealso \code{\link{AOI}}; \code{\link{netQuery}}
#' @references
#' @examples
#' function()
#' @export
mapTarget <- function(target, statesProb, what=c("class", "entropy", "probability"), msk, midvals=NULL, targetState=colnames(statesProb), spatial=TRUE, exportRaster=FALSE, path=getwd()){
    if(exportRaster == TRUE){
        rFormat <- '.tif'
    } else if (is.character(exportRaster)){
        rFormat <- exportRaster
    }
	what <- match.arg(what, c("class", "entropy", "probability", "expected", "variation"), several.ok = TRUE)
	if(spatial == TRUE){
		if(class(msk) == 'RasterLayer'){
			id <- msk
			id[] <- 1:length(id)
			id <- raster::getValues(id)[!is.na(raster::getValues(msk))]
			msk[] <- NA
		} else { 
			stop('"msk" must be an object of type "RasterLayer" as from raster::raster() function')
		}
	}
	whatList <- list()
	if('class' %in% what){
		Class <- as.factor(apply(statesProb, 1, function(x){colnames(statesProb)[which.max(x)]}) )
		if(spatial == TRUE){
			Class <- match(Class, colnames(statesProb))
			msk[id] <- Class
			Class <- msk
			keyLegend <- data.frame(colnames(statesProb), 1:length(colnames(statesProb)))
			names(keyLegend) <- c(target, 'ID')
			if(exportRaster == TRUE){
				raster::writeRaster(Class, paste(path, '/', target, '_Class', rFormat, sep=''), overwrite=TRUE, datatype='INT2S')
				write.csv(keyLegend, paste(path, target, '_ClassKey.csv', sep=''), row.names = FALSE)
			} else {
				print(keyLegend)
			}
		}
		whatList$Class <- Class
	}
 	if('expected' %in% what | 'variation' %in% what){
		if(is.null(midvals)){
			warning('Could not calculate the expected value (nor coefficient of variation) as either target node seems to be categorical or mid-values for each states of target node were not provided.')
		} else {
			Expected <- .expectedValue(statesProb, midvals)
			if('variation' %in% what){
				uncertainty <- sapply(1:length(Expected), function(x) {sqrt(sum((midvals - Expected[x])^2 * statesProb[x,]))})
				Variation <- uncertainty / Expected
				if(spatial == TRUE){ 
					msk[id] <- Variation
					Variation <- msk
					if(exportRaster == TRUE){
					    raster::writeRaster(Variation, paste(path, '/', target, '_CoeffVariation', rFormat, sep=''), overwrite=TRUE)
					}
				}
				whatList$CoeffVariation <- Variation			
			}
			if('expected' %in% what){
				if(spatial == TRUE){ 
					msk[id] <- Expected
					Expected <- msk
					if(exportRaster == TRUE){
						raster::writeRaster(Expected, paste(path, '/', target, '_ExpectedValue', rFormat, sep=''), overwrite=TRUE)
					}
				}
				whatList$ExpectedValue <- Expected
			}
		}
	}
	if('entropy' %in% what){
		Entropy <- apply(statesProb, 1, function(x){-x %*% log(x)} )
		if(spatial == TRUE){ 
			msk[id] <- Entropy
			Entropy <- msk
			if(exportRaster == TRUE){
			    raster::writeRaster(Entropy, paste(path, '/', target, '_Entropy', rFormat, sep=''), overwrite=TRUE)
			}
		}
		whatList$Entropy <- Entropy
	}	
	if('probability' %in% what){
		Probability <- lapply(targetState, function(x) {statesProb[, x]} )
		if(spatial == TRUE){
			Probability <- lapply(1:length(Probability), function(x) {msk[id] <- Probability[[x]]; return(msk)})	
		}
		names(Probability) <- targetState
		whatList$Probability <- Probability
		if(spatial == TRUE & exportRaster == TRUE){
			lapply(1:length(Probability), function(x) {raster::writeRaster(Probability[[x]], paste(path, '/', target, '_Probability_', targetState[x], rFormat, sep=''), overwrite=TRUE)})
		}
	}
	if(spatial == FALSE){
		xy <- raster::xyFromCell(msk, id)
		whatList <- cbind(id, xy, as.data.frame(whatList))
	}
	return(whatList)
}

.expectedValue <- function(statesProb, midvals) {
	return(apply(statesProb, 1, function(x){x %*% midvals}))
}


#' bnSpatialize
#' @title Spatialize the Bayesian network
#'
#' @description This function wraps most bnspatial package functions to ease the spatial implementation of Bayesian networks with minimal user interaction.
#' @inheritParams loadNetwork
#' @inheritParams mapTarget
#' @inheritParams linkNodeRaster
#' @inheritParams netQuery
#' @param inparallel logical. Should the function use parallel processing facilities? If TRUE, all cores/processors but one will be used.
#' An integer can be provided to dictate the number of cores/processors to be used.
#' @keywords
#' @return A list of "RasterLayer" objects or vectors, depending on input arguments: see \code{\link{mapTarget}}. 
#' Some basic information about discretization and #' network/data link are printed on screen during execution.
#' @author
#' @seealso \code{\link{setClasses}}; \code{\link{mapTarget}}; \code{\link{linkNodeRaster}}; \code{\link{loadNetwork}}
#' @references
#' @examples
#' function()
#' @export
bnSpatialize <- function(network, target, spatialData, lookup, msk=NULL, what=c("class", "entropy"), 
                         midvals=NULL, targetState=NULL, spatial=TRUE, inparallel=FALSE, exportRaster=FALSE, path=NULL, ...){
#	installMissingPackages(inparallel)
	network <- loadNetwork(network=network, target=target)

	## Load table with class boundaries, if available (otherwise make a list with node name and associated vector of class boundaries)
	if(class(lookup) == 'character' & length(lookup) == 1){
	    lookup <- importClasses(classFile=lookup)
	} else if (class(lookup) == 'list' & length(lookup)[[1]] == 3 & class(lookup)[[1]] == 'list'){
	    lookup <- lookup
	} else {
		stop('Check "lookup": must be a text file or a formatted list as output from "setClasses" and "importClasses" functions')
	}

	## Load input spatial data and corresponding nodes and states into a list
	if(class(spatialData) != 'character' | length(spatialData) != length(lookup)){
		stop('Check "spatialData": must be a vector of file names of length equal to the number of corresponding nodes')
	}
	spatialDataList <- linkNodeRasterList(spatialData=spatialData, network=network, lookup=lookup)

	## Load or create mask
	msk <- AOI(spDataLst=spatialDataList, msk=msk) 
	
	## Identify, index and get coordinates of valid cells (= non NA) from area of interest/mask
	id <- msk
	id[] <- 1:length(id)
	id <- raster::getValues(id)[!is.na(raster::getValues(msk))]
	xy <- raster::xyFromCell(msk, id)

#	## Remove spatial data that was set as evidence in the ellipsis (...)
#	if(length(list(...)) > 0){
#	ls() 
#		if(ls()... %in% names(spatialDataList)){
#			spatialDataList = spatialDataList[-which(... %in% names(spatialDataList))]
#		}
#	}

	## Extract data from locations, discretize and query Bayesian network
	if(inparallel != FALSE){
	    if(inparallel == TRUE){
	        mc <- parallel::detectCores()-1
	    } else {
	        mc <- inparallel
	    }
		cl <- parallel::makePSOCKcluster(mc)
		doParallel::registerDoParallel(cl)
		tab <- bulkDiscretize(formattedLst = spatialDataList, xy)
		probs <- netParallelQuery(network=network, target=target, evidence=tab, mc=mc, ...)
		parallel::stopCluster(cl); gc()
	} else {
		tab <- matrix(nrow=nrow(xy), ncol=length(spatialDataList))
		colnames(tab) <- names(spatialDataList)
		for(nm in colnames(tab)) {
			rst <- spatialDataList[[nm]]$Raster
			ex <- extractValuesByMask(rast=rst, msk=xy)
			if(spatialDataList[[nm]]$Categorical == TRUE){
				tab[, nm] <- spatialDataList[[nm]]$States[match(ex, spatialDataList[[nm]]$ClassBoundaries)]
			} else {
				tab[, nm] <- dataDiscretize(ex, spatialDataList[[nm]]$ClassBoundaries, spatialDataList[[nm]]$States)[[1]]
			}
		}
		probs <- netQuery(network=network, target=target, evidence=tab, ...)
	}
	mapTarget(target=target, statesProb=probs, what=what, msk=msk, midvals=midvals, spatial=spatial, targetState=targetState, exportRaster=exportRaster, path=path)
}

